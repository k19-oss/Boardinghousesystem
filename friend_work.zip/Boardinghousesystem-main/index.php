<?php
echo "It works!";
?>